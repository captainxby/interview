import cn.hutool.core.util.IdUtil;

/**
 * @auther zzyy
 * @create 2020-02-19 19:47
 */
public class T
{
    public static void main(String[] args)
    {
        System.out.println(IdUtil.simpleUUID());
    }
}
